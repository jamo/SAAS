require 'spec_helper'

describe "movies/similar.html.erb" do
  	
	#pending "add some examples to (or delete) #{__FILE__}"
end
